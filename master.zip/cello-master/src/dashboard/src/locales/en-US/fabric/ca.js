export default {
  'fabric.ca.form.adminName.label': 'Admin Username',
  'fabric.ca.form.adminName.placeholder': 'Input Admin Username',
  'fabric.ca.form.adminName.required': 'Please Input Admin Username',
  'fabric.ca.form.adminPassword.label': 'Admin Password',
  'fabric.ca.form.adminPassword.placeholder': 'Input Admin Password',
  'fabric.ca.form.adminPassword.required': 'Please Input Admin Password',
  'fabric.ca.form.caType.label': 'CA Type',
  'fabric.ca.form.caType.placeholder': 'Select CA Type',
  'fabric.ca.form.caType.required': 'Please Select CA Type',
};
