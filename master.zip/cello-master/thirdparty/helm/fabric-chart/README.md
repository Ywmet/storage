# Helm/Chart Repo for Deploying Fabric
------

This is a simple Chart to deploy Fabric on kubernetes, it's meant to provide an easy tool for user to deploy Fabric on kubernetes as well as offer a place for user to give their feedback about the Chart, you are welcome to share your comment at [rocketchat](https://chat.hyperledger.org/channel/cello).

For more details, please refer the following documents:
[English tutorial](http://www.think-foundry.com/hyperledger-fabric-deployment-using-helm-chart/)
[Chinese tutorial]( https://github.com/hainingzhang/articles/blob/master/fabric_helm/helmChartForFabric.pdf)
