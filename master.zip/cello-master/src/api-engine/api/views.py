#
# SPDX-License-Identifier: Apache-2.0
#
from django.shortcuts import render

# Create your views here.
