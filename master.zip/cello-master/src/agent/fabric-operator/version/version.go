package version

var (
	Version = "0.0.1"
)
