#
# SPDX-License-Identifier: Apache-2.0
#
from django.contrib import admin

# Register your models here.
