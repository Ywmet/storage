// +build tools

package tools

import (
	_ "sigs.k8s.io/controller-tools/pkg/crd/generator"
)
