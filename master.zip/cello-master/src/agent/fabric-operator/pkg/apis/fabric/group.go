// Package fabric contains fabric API versions.
//
// This file ensures Go source parsers acknowledge the fabric package
// and any child packages. It can be removed if any other Go source files are
// added to this package.
package fabric
