export default {
  'fabric.ca.form.adminName.label': '管理员用户名',
  'fabric.ca.form.adminName.placeholder': '输入管理员用户名',
  'fabric.ca.form.adminName.required': '请输入管理员用户名',
  'fabric.ca.form.adminPassword.label': '管理员密码',
  'fabric.ca.form.adminPassword.placeholder': '输入管理员密码',
  'fabric.ca.form.adminPassword.required': '请输入管理员密码',
  'fabric.ca.form.caType.label': 'CA类型',
  'fabric.ca.form.caType.placeholder': '选择CA类型',
  'fabric.ca.form.caType.required': '请选择CA类型',
};
