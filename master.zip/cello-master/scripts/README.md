# Scripts

Here we collect scripts to help setup and manage the lifecycle of cello service.

Most of them are needed by the master node.

Those under [worker_node_setup](worker_node) directory should be put at the worker node to help setup.

<a rel="license" href="http://creativecommons.org/licenses/by/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by/4.0/">Creative Commons Attribution 4.0 International License</a>
