#
# SPDX-License-Identifier: Apache-2.0
#
from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = "api"
