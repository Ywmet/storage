export default {
  'component.tagSelect.expand': '展开',
  'component.tagSelect.collapse': '收起',
  'component.tagSelect.all': '全部',
  'component.miniProgress.tooltipDefault': '目标值',
  'component.standardTable.selected': '已选择',
  'component.standardTable.item': '项',
  'component.standardTable.total': '总计',
  'component.standardTable.clean': '清空',
  'component.standardTable.showTotal': '{start}-{end} 总共 {total} 项',
};
