#!/usr/bin/env bash
SCRIPTS_PATH=/scripts

bash ${SCRIPTS_PATH}/change_local_settings.sh

echo "All initial Done!!"