export default {
  'component.tagSelect.expand': 'Expand',
  'component.tagSelect.collapse': 'Collapse',
  'component.tagSelect.all': 'All',
  'component.miniProgress.tooltipDefault': 'Target value',
  'component.standardTable.selected': 'Selected',
  'component.standardTable.item': 'Item',
  'component.standardTable.total': 'Total',
  'component.standardTable.clean': 'Clean',
  'component.standardTable.showTotal': '{start}-{end} of {total} items',
};
